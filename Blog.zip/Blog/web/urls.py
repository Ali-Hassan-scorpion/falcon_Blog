from django.contrib import admin
from django.urls import path,include

from web import views

urlpatterns = [
    path('', views.loginpage, name='loginpage'),
    path('Signup', views.Signup, name='Signup'),
    path('my_logout', views.my_logout, name='my_logout'),
    path('index', views.index, name='index'),
    path('My_Blog', views.My_Blog, name='My_Blog'),
    path('Edit_Blog/<str:id>', views.Edit_Blog, name='Edit_Blog'),
    path('Blog_Del/<str:id>', views.Blog_Del, name='Blog_Del'),
]