from .models import *
from .form import adduser
from django.contrib.auth import authenticate ,login,logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.shortcuts import redirect
from django.shortcuts import render

# Create your views here.
def loginpage(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        # if user is not None and user.userRole == 'is_admin':
        userId = username
        login(request, user)
        return redirect('index')

    else:
        context = {}
        return render(request, 'pages/login.html', context)
# ----------------------------------  logout --------------------------------------------
def my_logout(request):
    logout(request)
    return redirect('loginpage')
# -----------------------------------   index ----------------------------------------------
def index(request):
    return render(request, 'index.html')

def Signup(request):
    if request.method == "POST":
        form = adduser(request.POST, request.FILES)
        if form.is_valid():
            form.save(commit=False)
            form.instance.Form_img = request.FILES['Form_img']
            form.save()
    else:
        form = adduser()

    return render(request, 'pages/signup.html', {'form': form})
    # ===================================  Blog ==========================================
@login_required(login_url='login')
def My_Blog(request):
        if request.method == 'POST':

                title = request.POST.get('title')
                content = request.POST.get('content')
                author_username = request.user.username
                author = User_ss.objects.get(username=author_username)
                created_at = request.POST.get('created_at')
                blog = Blog(title=title, content=content, author=author,
                                     created_at=created_at)
                blog.save()
        blog_view = Blog.objects.all()
        return render(request, 'pages/blog.html', {'blog_view': blog_view})



# -----------------------------------------------   Vehicle Edit  --------------------------------
def Edit_Blog(request, id):
    if request.method == 'POST':
        title = request.POST.get('title')
        content = request.POST.get('content')
        author = request.POST.user
        created_at = request.POST.get('created_at')
        blog = Blog(id=id,title=title, content=content, author=author,
                    created_at=created_at)
        blog.save()
    return redirect(My_Blog)

def Blog_Del(request, id):
        client = Blog.objects.filter(id=id)
        client.delete()
        return redirect(My_Blog)