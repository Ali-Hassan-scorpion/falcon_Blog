from django.contrib.auth.models import User
from django import forms
from django.contrib.auth.forms import UserCreationForm

from .models import User_ss
class adduser(UserCreationForm):

    contactNumber = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Contact No'}))
    password1 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Password With uper,char,lower,no'}))
    password2 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Password Again'}))
    Form_img = forms.ImageField()


    class Meta:
        model = User_ss
        fields = ['username','contactNumber','password1','password2','Form_img']

