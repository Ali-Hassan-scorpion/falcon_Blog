from django.contrib import admin
from web.models import *

# Register your models here

admin.site.register(User_ss)
admin.site.register(Blog)

